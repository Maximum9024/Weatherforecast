﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task_2
{
    public partial class Form1 : Form
    {
        //Function class instance
        myFunctions myobj = new myFunctions();
        int Rowindex;
        public Form1()
        {
            InitializeComponent();
            //initializing grid columns       
            gridCity.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            //loading the cities to the select combbox
            myobj.LoadToCitySelect(City_select);
            //loading the table
            myobj.dt_Load();


        }

      
        private void btnCapture_Click(object sender, EventArgs e)
        {
            //calling the capture method
            myobj.CaptureMethod(txtboxCity, datetime, txtboxMintemp, txtboxMaxtemp, txtboxPrecip, txtboxHumid, txtboxWindspd);
        }

        private void btnViewCity_Click(object sender, EventArgs e)
        {
            //calling the ViewMethod
            myobj.ViewMethod(gridCity, City_select, datetimeFrom, datetimeTo);
        }

        //to get values of the selected index
        private void gridCity_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Rowindex = e.RowIndex;
            DataGridViewRow row = gridCity.Rows[Rowindex];
            txtboxCity.Text = row.Cells[0].Value.ToString();
            datetime.Text = row.Cells[1].Value.ToString();
            txtboxMintemp.Text = row.Cells[2].Value.ToString();
            txtboxMaxtemp.Text = row.Cells[3].Value.ToString();
            txtboxPrecip.Text = row.Cells[4].Value.ToString();
            txtboxHumid.Text = row.Cells[5].Value.ToString();
            txtboxWindspd.Text = row.Cells[6].Value.ToString();

        }

        //button to to edit the selected index
        private void btnEdit_Click(object sender, EventArgs e)
        {
            try
            {
                if (Rowindex >= 0)
                {
                    DataGridViewRow DataRow = gridCity.Rows[Rowindex];
                    DataRow.Cells[0].Value = txtboxCity.Text;
                    DataRow.Cells[1].Value = datetime.Text;
                    DataRow.Cells[2].Value = txtboxMintemp.Text;
                    DataRow.Cells[3].Value = txtboxMaxtemp.Text;
                    DataRow.Cells[4].Value = txtboxPrecip.Text;
                    DataRow.Cells[5].Value = txtboxHumid.Text;
                    DataRow.Cells[6].Value = txtboxWindspd.Text;
                    MessageBox.Show("Forecast updated.");

                }
                else
                {
                    MessageBox.Show("Please select the row to update");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnViewCities_Click(object sender, EventArgs e)
        {
            //calling the button to view all the cities
            myobj.searchMethod2(datetimeFrom2, datetimeTo2, gridCity);  
        }

        
        private void btnClear_Click(object sender, EventArgs e)
        {
            //calling the clear method
            myobj.clearMethod(City_select, txtboxMintemp, txtboxMaxtemp, txtboxPrecip, txtboxHumid, txtboxWindspd, txtboxCity);
        }

        private void datetimeFrom2_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
