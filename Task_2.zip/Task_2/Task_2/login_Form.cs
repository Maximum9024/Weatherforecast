﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task_2
{
    public partial class login_Form : Form
    {
        public login_Form()
        {
            InitializeComponent();
        }
        
        myFunctions myObj = new myFunctions();
        private void button1_Click(object sender, EventArgs e)
        {
            //calling the login method
            myObj.loginMethod(txtboxUser, txtboxPass, rdiobtn_Yes, rdiobtn_No);
        }
    }
}
