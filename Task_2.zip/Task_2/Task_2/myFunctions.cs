﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task_2
{
    class myFunctions
    {
        //variable declarations
        List<string> username = new List<string>();
        List<string> password = new List<string>();
        DataTable dt = new DataTable("weather forecast");

        //method to initialize the datatable
        public void dt_Load()
        {
            dt.Columns.Add("City", typeof(string));
            dt.Columns.Add("Date");
            dt.Columns.Add("Minimum temperature", typeof(int));
            dt.Columns.Add("Maximum temperature", typeof(int));
            dt.Columns.Add("Precipitation", typeof(int));
            dt.Columns.Add("Humidity", typeof(int));
            dt.Columns.Add("Wind speed", typeof(int));
         



        }

        //method to login
        public void loginMethod(TextBox txtUser,TextBox txtPass, RadioButton rdioYes, RadioButton rdioNo)
        {
            string[] login_info;
           
            string file = "C:\\Users\\MAX\\Documents\\Visual Studio 2015\\Projects\\Task_2\\login_info.txt";
            StreamReader sRead = new StreamReader(file);
            string line = "";
            Form1 form = new Form1();
            login_Form LoginForm = new login_Form();
            while ((line =sRead.ReadLine()) !=null)
            {
                login_info = line.Split(",".ToCharArray(),StringSplitOptions.RemoveEmptyEntries);
                username.Add(login_info[0]);
                password.Add(login_info[1]);

            }
            if (username.Contains(txtUser.Text) && password.Contains(txtPass.Text) && Array.IndexOf(username.ToArray(), txtUser.Text) == Array.IndexOf(password.ToArray(), txtPass.Text))
                {
                if (rdioYes.Checked==true)
                {
                    
                    foreach (Control c in form.Controls)
                    {
                        if (c.Name == "grpboxCapture")
                            c.Visible = true;
                    }
                    LoginForm.Close();
                    form.ShowDialog();
                }
                else if(rdioNo.Checked==true)
                {
                    LoginForm.Close();
                    form.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Please answer the question provided.");
                }
               
            }
            else
            {
                MessageBox.Show("invalid login details! Please enter the correct details");
            }
        }
     
        //method to read from text file
        public void ReadMethod()
        {
            string file = "C:\\Users\\MAX\\Documents\\Visual Studio 2015\\Projects\\Task_2\\weather_info.txt";

            using (TextReader tRead = File.OpenText(file))
            {
                string line;
                while ((line = tRead.ReadLine()) != null)
                {
                    string[] properties = line.Trim().Split(',');

                    dt.Rows.Add(properties);
                }
            }
        }

        //Load items to the combo box
        public void LoadToCitySelect( ComboBox citySelect)
        {
            string file = "C:\\Users\\MAX\\Documents\\Visual Studio 2015\\Projects\\Task_2\\weather_info.txt";

            string[] Data = File.ReadAllLines(file);
            foreach (var item in Data)
            {
                string[] city = item.Split(',');
                if (!citySelect.Items.Contains(city[0]))
                {
                    citySelect.Items.Add(city[0]);
                }



            }
        }
       
        //capture method
        public void CaptureMethod(TextBox txtCity, DateTimePicker datetime, TextBox txtMin, TextBox txtMax, TextBox txtPrecip, TextBox txtHumid, TextBox txtWindspd)
        {
            try
            {

                if (txtCity.Text != null && txtCity.Text != "" && txtMin.Text != "" && txtMax.Text != "" && txtPrecip.Text != "" && txtHumid.Text != "" && txtWindspd.Text != "")
                {
                    string file = "C:\\Users\\MAX\\Documents\\Visual Studio 2015\\Projects\\Task_2\\weather_info.txt";
                    string[] forecast = new string[7];
                    forecast[0] = txtCity.Text;
                    forecast[1] = datetime.Text;
                    forecast[2] = txtMin.Text;
                    forecast[3] = txtMax.Text;
                    forecast[4] = txtPrecip.Text;
                    forecast[5] = txtHumid.Text;
                    forecast[6] = txtWindspd.Text;
                    using (StreamWriter sWrite = new StreamWriter(file, true))
                    {
                        sWrite.WriteLine(forecast[0] + "," + forecast[1] + "," + forecast[2] + "," + forecast[3] + ","
                            + forecast[4] + "," + forecast[5] + "," + forecast[6]);
                        sWrite.Flush();

                    }

                    MessageBox.Show("City forecast captured");
                }
                else
                {
                    MessageBox.Show("invalid forecast data! enter all details correctly.");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
      
      
        //Method to clear all fields
        public void clearMethod(ComboBox City_val, TextBox txt_Min, TextBox txt_Max, TextBox Precip_val, TextBox Humid_val, TextBox Wind_spd, TextBox txt_search)
        {
            City_val.Text = "";
            txt_Min.Text = "";
            txt_Max.Text = "";
            Precip_val.Text = "";
            Humid_val.Text = "";
            Wind_spd.Text = "";
            txt_search.Text = "";
        }


        //Display  search method
        public void ViewMethod(DataGridView dataGrid,ComboBox citySelect, DateTimePicker dateTime_from,DateTimePicker dateTime_To)
        {
           

            try
            {
                if (citySelect.Text !="")
                {
                    ReadMethod();
                    dt.DefaultView.RowFilter = null; ;
                    dataGrid.DataSource = dt;
                    dt.DefaultView.RowFilter = string.Format("[{0}] LIKE '%{2}%' AND [{1}] >= #{3}# AND [{1}] <=#{4}#", "City", "Date", citySelect.Text, dateTime_from.Text, dateTime_To.Text);
                    Min_Temp(dataGrid);
                    Max_Temp(dataGrid);

                }
                else
                {
                    MessageBox.Show("Select bar empty");
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
       

        //Method to Edit the selected specified city
        public void editMethod(TextBox City_val, DateTimePicker datetime, TextBox txt_Min, TextBox txt_Max, TextBox Precip_val, TextBox Humid_val, TextBox Wind_spd)
        {
            try
            {
                ReadMethod();
                foreach (DataRow row in dt.Rows)
                {
                    if (row["City"].ToString() == City_val.Text)
                    {
                        row.SetField("City", City_val.Text);
                        row.SetField("Date", datetime.Text);
                        row.SetField("Minimum temperature", txt_Min.Text);
                        row.SetField("Maximum Temperature", txt_Max.Text);
                        row.SetField("Precipitation", Precip_val.Text);
                        row.SetField("Humidity", Humid_val.Text);
                        row.SetField("Wind speed", Wind_spd.Text);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Search method for all the cities in a specified date range
        public void searchMethod2(DateTimePicker datetimeFrom, DateTimePicker datetimeTo, DataGridView disp_data)
        {

            try
            {
                ReadMethod();
                    dt.DefaultView.RowFilter = null; ;
                    disp_data.DataSource = dt;
                    dt.DefaultView.RowFilter = string.Format("[{0}] >=#{1}# AND [{0}] <=#{2}#", "Date", datetimeFrom.Text, datetimeTo.Text);
                    Max_Temp(disp_data);
                    Min_Temp(disp_data);
              

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }
     
        //Max Temperature
        public void Max_Temp(DataGridView disp_data)

        {


            int max = 0;

            //finding the maximum value
            for (int i = 0; i < disp_data.Rows.Count; i++)
            {
                if (disp_data.Rows[i].Cells[3].Value != null)
                {
                    int temp = Int32.Parse(disp_data.Rows[i].Cells[3].Value.ToString());


                    if (max < temp)
                    {
                        max = temp;
                    }
                }

            }

            //setting the colour green for maximum temperature
            for (int i = 0; i < disp_data.Rows.Count; i++)
            {
                if (disp_data.Rows[i].Cells[3].Value != null)
                {
                    int temp = Int32.Parse(disp_data.Rows[i].Cells[3].Value.ToString());
                    if (temp == max)
                    {

                        disp_data.Rows[i].DefaultCellStyle.BackColor = Color.LightGreen;
                    }

                }
            }


        }


        //Min temperature
        public void Min_Temp(DataGridView disp_data)
        {
            int Min_value = 101;
            //finding the mainimum value
            for (int i = 0; i < disp_data.Rows.Count; i++)
            {
                if (disp_data.Rows[i].Cells[2].Value != null)
                {
                    int temp = Int32.Parse(disp_data.Rows[i].Cells[2].Value.ToString());


                    if (Min_value > temp)
                    {
                        Min_value = temp;
                    }
                }

            }

            //setting the colour green for minimum temperature
            for (int i = 0; i < disp_data.Rows.Count; i++)
            {
                if (disp_data.Rows[i].Cells[2].Value != null)
                {
                    int temp = Int32.Parse(disp_data.Rows[i].Cells[2].Value.ToString());
                    if (temp == Min_value)
                    {

                        disp_data.Rows[i].DefaultCellStyle.BackColor = Color.Yellow;
                    }

                }
            }


        }

    }
}
