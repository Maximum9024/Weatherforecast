﻿use [C:\USERS\MAX\DOCUMENTS\VISUAL STUDIO 2015\PROJECTS\POE\POE\WFORECASETDB.MDF];
create table loginTabble(id int IDENTITY(1,1) PRIMARY KEY,
                          userName varchar(255) NOT NULL,
						  passWord varchar(255));

create table wforecastTable(  city varchar(255) NOT NULL,
							 entryDate varchar(255) NOT NULL,
							 MinTemp varchar(255) NOT NULL,
							 MaxTemp varchar(255) NOT NULL,
							 Precip varchar(255) NOT NULL,
							 Humid varchar(255) NOT NULL,
							 Speed varchar(255) NOT NULL)

select * from wforecastTable;
insert into wforecastTable values('Pretoria','2020/10/08','12','24','11','8','6');
