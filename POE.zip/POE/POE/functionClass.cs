﻿using System;
using System.Collections.Generic;
using System.Data.Sql;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;

namespace POE
{
    class functionClass
    {
        //variable declarations
        List<string> username = new List<string>();
        List<string> password = new List<string>();
        DataTable dt = new DataTable("weather forecast");
        string sql="";
         string Connectionstring= @"Data Source=DESKTOP-RDJMGOE\SQLEXPRESS; initial catalog=forecastDB ; Integrated Security=True;Connect Timeout=15;";

        //method to initialize the datatable
        public void dt_Load()
        {
            dt.Columns.Add("City", typeof(string));
            dt.Columns.Add("Date");
            dt.Columns.Add("Minimum temperature", typeof(int));
            dt.Columns.Add("Maximum temperature", typeof(int));
            dt.Columns.Add("Precipitation", typeof(int));
            dt.Columns.Add("Humidity", typeof(int));
            dt.Columns.Add("Wind speed", typeof(int));




        }
        //Method to clear all fields
        public void clearMethod(ComboBox City_val, TextBox txt_Min, TextBox txt_Max, TextBox Precip_val, TextBox Humid_val, TextBox Wind_spd, TextBox txt_search)
        {
            City_val.Text = "";
            txt_Min.Text = "";
            txt_Max.Text = "";
            Precip_val.Text = "";
            Humid_val.Text = "";
            Wind_spd.Text = "";
            txt_search.Text = "";
        }

        //method to login
        public void loginMethod(TextBox txtUser, TextBox txtPass, RadioButton rdioYes, RadioButton rdioNo)
        {
            sql = "Select * from loginTable where userName='" + txtUser.Text + "' and passWord='" + txtPass.Text + "'";
            ConnectDB(sql);
            if (dt.Rows.Count ==1)
            {
                forecastForm form = new forecastForm();
                Login_Form LoginForm = new Login_Form();
                if (rdioYes.Checked == true)
                {

                    foreach (Control c in form.Controls)
                    {
                        if (c.Name == "grpboxCapture")
                            c.Visible = true;
                    }
                    LoginForm.Hide();
                    form.Show();
                }
                else if (rdioNo.Checked == true)
                {
                    LoginForm.Hide();
                    form.Show();
                }
                else
                {
                    MessageBox.Show("Please answer the question provided.");
                }
            }
            else
            {
                MessageBox.Show("invalid login details! Please enter the correct details");
            }


           
            
        }
        //capture method
        public void CaptureMethod(TextBox txtCity, DateTimePicker datetime, TextBox txtMin, TextBox txtMax, TextBox txtPrecip, TextBox txtHumid, TextBox txtWindspd)
        {
            try
            {
             
                if (txtCity.Text != null && txtCity.Text != "" && txtMin.Text != "" && txtMax.Text != "" && txtPrecip.Text != "" && txtHumid.Text != "" && txtWindspd.Text != "")
                {
                    string Query = "INSERT INTO forecastTable(city,entryDate,minTemp,maxTemp,Precip,Humid,Speed) VALUES ('" + txtCity.Text + "','" + datetime.Text + "','" + txtMin.Text + "','" + txtMax.Text + "','" + txtPrecip.Text + "','" + txtHumid.Text + "','" + txtWindspd.Text + "')";

                    SqlConnection con = new SqlConnection(Connectionstring);
                    con.Open();

                    SqlCommand cmd = new SqlCommand(Query, con);
                    SqlDataAdapter da = new SqlDataAdapter();
                    da.InsertCommand = new SqlCommand(Query, con);
                    da.InsertCommand.ExecuteNonQuery();
                   
                    cmd.Dispose();

                    con.Close();


                    MessageBox.Show("City forecast captured");
                }
                else
                {
                    MessageBox.Show("invalid forecast data! enter all details correctly.");
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Method to Edit the selected specified city
        public void editMethod(TextBox City_val, DateTimePicker datetime, TextBox txt_Min, TextBox txt_Max, TextBox Precip_val, TextBox Humid_val, TextBox Wind_spd)
        {
            try
            {
                sql = "select * from wforecastTable";
                ConnectDB(sql);
                foreach (DataRow row in dt.Rows)
                {
                    if (row["City"].ToString() == City_val.Text)
                    {
                        row.SetField("City", City_val.Text);
                        row.SetField("Date", datetime.Text);
                        row.SetField("Minimum temperature", txt_Min.Text);
                        row.SetField("Maximum Temperature", txt_Max.Text);
                        row.SetField("Precipitation", Precip_val.Text);
                        row.SetField("Humidity", Humid_val.Text);
                        row.SetField("Wind speed", Wind_spd.Text);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
      
        
        //method to connext to the database
        public void ConnectDB(string sqlQuery)
        {
      
            SqlConnection con= new SqlConnection(Connectionstring);
            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            con.Open();
            
            da.Fill(dt);
            con.Close();
            da.Dispose();
            
        }

        //Load items to the combo box
        public void LoadToCitySelect(ComboBox citySelect)
        {
            try
            {
                sql = "select * from forecastTable";
                SqlConnection con = new SqlConnection(Connectionstring);
                SqlCommand cmd = new SqlCommand(sql, con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    if (!citySelect.Items.Contains(dr.GetString(0)))
                    {
                        citySelect.Items.Add(dr.GetString(0));
                    }
                }
                con.Close();
                da.Dispose();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           
            
        }

        //Display  search method
        public void ViewMethod(DataGridView dataGrid, ComboBox citySelect, DateTimePicker dateTime_from, DateTimePicker dateTime_To)
        {


            try
            {
                if (citySelect.Text != "")
                {
                    sql = "select * from forecastTable where city like '"+citySelect.Text+"'";
                    ConnectDB(sql);
                    dt.DefaultView.RowFilter = null; ;
                    dataGrid.DataSource = dt;
                    dt.DefaultView.RowFilter = string.Format("[{0}] LIKE '%{2}%' AND [{1}] >= #{3}# AND [{1}] <=#{4}#", "city", "entryDate", citySelect.Text, dateTime_from.Text, dateTime_To.Text);
                    Min_Temp(dataGrid);
                    Max_Temp(dataGrid);

                }
                else
                {
                    MessageBox.Show("Select bar empty");
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
      
        //Search method for all the cities in a specified date range
        public void searchMethod2(DateTimePicker datetimeFrom, DateTimePicker datetimeTo, DataGridView disp_data)
        {

            try
            {
                sql = "select * from forecastTable";
                ConnectDB(sql);
                dt.DefaultView.RowFilter = null; ;
                disp_data.DataSource = dt;
                dt.DefaultView.RowFilter = string.Format("[{0}] >=#{1}# AND [{0}] <=#{2}#", "entryDate", datetimeFrom.Text, datetimeTo.Text);
                Max_Temp(disp_data);
                Min_Temp(disp_data);


            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }
   
        //method to update or insert to the database
        public void InsertUpdateDB( string sqlQuery)
        {

            SqlConnection con = new SqlConnection(Connectionstring);
            con.Open();

            SqlCommand cmd = new SqlCommand(sqlQuery, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
         cmd.ExecuteNonQuery();
            da.Fill(dt);
          cmd.Dispose();
           
            con.Close();
          


        }
        
        //Max Temperature
        public void Max_Temp(DataGridView disp_data)

        {


            int max = 0;

            //finding the maximum value
            for (int i = 0; i < disp_data.Rows.Count; i++)
            {
                if (disp_data.Rows[i].Cells[3].Value != null)
                {
                    int temp = Int32.Parse(disp_data.Rows[i].Cells[3].Value.ToString());


                    if (max < temp)
                    {
                        max = temp;
                    }
                }

            }

            //setting the colour green for maximum temperature
            for (int i = 0; i < disp_data.Rows.Count; i++)
            {
                if (disp_data.Rows[i].Cells[3].Value != null)
                {
                    int temp = Int32.Parse(disp_data.Rows[i].Cells[3].Value.ToString());
                    if (temp == max)
                    {

                        disp_data.Rows[i].DefaultCellStyle.BackColor = Color.LightGreen;
                    }

                }
            }


        }

        //Min temperature
        public void Min_Temp(DataGridView disp_data)
        {
            int Min_value = 101;
            //finding the mainimum value
            for (int i = 0; i < disp_data.Rows.Count; i++)
            {
                if (disp_data.Rows[i].Cells[2].Value != null)
                {
                    int temp = Int32.Parse(disp_data.Rows[i].Cells[2].Value.ToString());


                    if (Min_value > temp)
                    {
                        Min_value = temp;
                    }
                }

            }

            //setting the colour green for minimum temperature
            for (int i = 0; i < disp_data.Rows.Count; i++)
            {
                if (disp_data.Rows[i].Cells[2].Value != null)
                {
                    int temp = Int32.Parse(disp_data.Rows[i].Cells[2].Value.ToString());
                    if (temp == Min_value)
                    {

                        disp_data.Rows[i].DefaultCellStyle.BackColor = Color.Yellow;
                    }

                }
            }


        }




    }
}
