﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POE
{
    public partial class forecastForm : Form
    {
        //creating an instance for the functionClass
        functionClass myOBj = new functionClass();

        public forecastForm()
        {
            InitializeComponent();
            //initializing grid columns       
            gridCity.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            //loading the cities to the select combbox
            myOBj.LoadToCitySelect(City_select);

          
        }
         
        private void btnCapture_Click(object sender, EventArgs e)
        {
            // calling the capture method
            myOBj.CaptureMethod(txtboxCity, datetime, txtboxMintemp, txtboxMaxtemp, txtboxPrecip,txtboxHumid, txtboxWindspd);

        }

        private void btnViewCity_Click(object sender, EventArgs e)
        {
            //calling the display method
            myOBj.ViewMethod(gridCity, City_select, datetimeFrom, datetimeTo);
        }

        private void btnViewCities_Click(object sender, EventArgs e)
        {
            //calling the search method between dates
            myOBj.searchMethod2(datetimeFrom, datetimeTo, gridCity);
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            //calling the the method to edit a record
            myOBj.editMethod(txtboxCity, datetime, txtboxMintemp, txtboxMaxtemp, txtboxPrecip, txtboxHumid, txtboxWindspd);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            //calling the method to clear fields
            myOBj.clearMethod(City_select, txtboxMintemp, txtboxMaxtemp, txtboxPrecip, txtboxHumid, txtboxWindspd, txtboxCity);
        }
    }
}
