﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task_1
{
    public partial class Form1 : Form
    {
        // Function class instance
        Function_Class myObjects = new Function_Class();
        int Rowindex;
        public Form1()
        {
            InitializeComponent();
            
            //initializing grid columns       
            gridCity.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
  
            //loading the table
            myObjects.dt_Load();
 
        }

       

        private void btnCapture_Click(object sender, EventArgs e)
        {
            //calling the capture method
            myObjects.captureMethod(City_select,txtboxCity, datetime,txtboxMintemp, txtboxMaxtemp,txtboxPrecip,txtboxHumid,txtboxWindspd);
        }


        private void btnViewCity_Click(object sender, EventArgs e)
        {
            //calling the method to view the weather forcast data 
            myObjects.SearchMethod(City_select,datetimeFrom,datetimeTo,gridCity);
           
        }

        //To get the selected Row index values
        private void gridCity_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Rowindex = e.RowIndex;
            DataGridViewRow row = gridCity.Rows[Rowindex];
            txtboxCity.Text = row.Cells[0].Value.ToString();
            datetime.Text = row.Cells[1].Value.ToString();
            txtboxMintemp.Text = row.Cells[2].Value.ToString();
            txtboxMaxtemp.Text = row.Cells[3].Value.ToString();
            txtboxPrecip.Text = row.Cells[4].Value.ToString();
            txtboxHumid.Text = row.Cells[5].Value.ToString();
            txtboxWindspd.Text = row.Cells[6].Value.ToString();


        }

        //Button to edit the select weather forecast
        private void btnEdit_Click(object sender, EventArgs e)
        {
          try
            {
                if (Rowindex >=0)
                {
                    DataGridViewRow DataRow = gridCity.Rows[Rowindex];
                    DataRow.Cells[0].Value = txtboxCity.Text;
                    DataRow.Cells[1].Value = datetime.Text;
                    DataRow.Cells[2].Value = txtboxMintemp.Text;
                    DataRow.Cells[3].Value = txtboxMaxtemp.Text;
                    DataRow.Cells[4].Value = txtboxPrecip.Text;
                    DataRow.Cells[5].Value = txtboxHumid.Text;
                    DataRow.Cells[6].Value = txtboxWindspd.Text;
                    MessageBox.Show("Forecast updated.");

                }
                else
                {
                    MessageBox.Show("Please select the row to update");
                }
              
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           

        }

        //calling the clear method
        private void btnClear_Click(object sender, EventArgs e)
        {
            myObjects.clearMethod(City_select,txtboxCity,txtboxMintemp,txtboxMaxtemp,txtboxPrecip,txtboxHumid,txtboxWindspd);
        }

        private void btnViewCities_Click(object sender, EventArgs e)
        {
            //Calling the view all cities methods
            myObjects.searchMethod2(datetimeFrom2, datetimeTo2, gridCity);
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }
    }
}
