﻿namespace Task_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.gridCity = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.City_select = new System.Windows.Forms.ComboBox();
            this.datetimeTo = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.btnViewCity = new System.Windows.Forms.Button();
            this.datetimeFrom = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnViewCities = new System.Windows.Forms.Button();
            this.datetimeTo2 = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.datetimeFrom2 = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.datetime = new System.Windows.Forms.DateTimePicker();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnCapture = new System.Windows.Forms.Button();
            this.txtboxWindspd = new System.Windows.Forms.TextBox();
            this.txtboxHumid = new System.Windows.Forms.TextBox();
            this.txtboxPrecip = new System.Windows.Forms.TextBox();
            this.txtboxMaxtemp = new System.Windows.Forms.TextBox();
            this.txtboxMintemp = new System.Windows.Forms.TextBox();
            this.txtboxCity = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridCity)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(384, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(305, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Weather forecasting system";
            // 
            // dataGridView1
            // 
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(240, 150);
            this.dataGridView1.TabIndex = 0;
            // 
            // gridCity
            // 
            this.gridCity.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridCity.Location = new System.Drawing.Point(6, 112);
            this.gridCity.Name = "gridCity";
            this.gridCity.Size = new System.Drawing.Size(655, 340);
            this.gridCity.TabIndex = 20;
            this.gridCity.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridCity_CellClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.City_select);
            this.groupBox1.Controls.Add(this.datetimeTo);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.btnViewCity);
            this.groupBox1.Controls.Add(this.datetimeFrom);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Location = new System.Drawing.Point(544, 80);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(697, 731);
            this.groupBox1.TabIndex = 23;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Weather forecast for the Specified city";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(36, 113);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(335, 13);
            this.label14.TabIndex = 40;
            this.label14.Text = " Green = High Temperature       Yellow = Low temperature";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // City_select
            // 
            this.City_select.FormattingEnabled = true;
            this.City_select.Location = new System.Drawing.Point(121, 39);
            this.City_select.Name = "City_select";
            this.City_select.Size = new System.Drawing.Size(200, 21);
            this.City_select.TabIndex = 39;
            // 
            // datetimeTo
            // 
            this.datetimeTo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datetimeTo.Location = new System.Drawing.Point(366, 80);
            this.datetimeTo.Name = "datetimeTo";
            this.datetimeTo.Size = new System.Drawing.Size(200, 20);
            this.datetimeTo.TabIndex = 26;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(329, 82);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(30, 13);
            this.label12.TabIndex = 25;
            this.label12.Text = "To :";
            // 
            // btnViewCity
            // 
            this.btnViewCity.BackColor = System.Drawing.Color.Tomato;
            this.btnViewCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewCity.Location = new System.Drawing.Point(451, 19);
            this.btnViewCity.Name = "btnViewCity";
            this.btnViewCity.Size = new System.Drawing.Size(115, 47);
            this.btnViewCity.TabIndex = 38;
            this.btnViewCity.Text = "View";
            this.btnViewCity.UseVisualStyleBackColor = false;
            this.btnViewCity.Click += new System.EventHandler(this.btnViewCity_Click);
            // 
            // datetimeFrom
            // 
            this.datetimeFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datetimeFrom.Location = new System.Drawing.Point(121, 80);
            this.datetimeFrom.Name = "datetimeFrom";
            this.datetimeFrom.Size = new System.Drawing.Size(200, 20);
            this.datetimeFrom.TabIndex = 23;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(36, 82);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(73, 13);
            this.label11.TabIndex = 22;
            this.label11.Text = "Date From :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(36, 39);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 13);
            this.label9.TabIndex = 21;
            this.label9.Text = "Select a city";
            // 
            // groupBox2
            // 
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 100);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnViewCities);
            this.groupBox3.Controls.Add(this.datetimeTo2);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.datetimeFrom2);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.gridCity);
            this.groupBox3.Location = new System.Drawing.Point(544, 218);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(697, 562);
            this.groupBox3.TabIndex = 24;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Weather forecast for the selected cities";
            // 
            // btnViewCities
            // 
            this.btnViewCities.BackColor = System.Drawing.Color.Tomato;
            this.btnViewCities.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewCities.Location = new System.Drawing.Point(451, 26);
            this.btnViewCities.Name = "btnViewCities";
            this.btnViewCities.Size = new System.Drawing.Size(115, 47);
            this.btnViewCities.TabIndex = 39;
            this.btnViewCities.Text = "View";
            this.btnViewCities.UseVisualStyleBackColor = false;
            this.btnViewCities.Click += new System.EventHandler(this.btnViewCities_Click);
            // 
            // datetimeTo2
            // 
            this.datetimeTo2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datetimeTo2.Location = new System.Drawing.Point(366, 86);
            this.datetimeTo2.Name = "datetimeTo2";
            this.datetimeTo2.Size = new System.Drawing.Size(200, 20);
            this.datetimeTo2.TabIndex = 3;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(329, 92);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(30, 13);
            this.label13.TabIndex = 2;
            this.label13.Text = "To :";
            // 
            // datetimeFrom2
            // 
            this.datetimeFrom2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datetimeFrom2.Location = new System.Drawing.Point(121, 85);
            this.datetimeFrom2.Name = "datetimeFrom2";
            this.datetimeFrom2.Size = new System.Drawing.Size(200, 20);
            this.datetimeFrom2.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(36, 85);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 13);
            this.label10.TabIndex = 0;
            this.label10.Text = "Date From :";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.datetime);
            this.groupBox4.Controls.Add(this.btnClear);
            this.groupBox4.Controls.Add(this.btnEdit);
            this.groupBox4.Controls.Add(this.btnCapture);
            this.groupBox4.Controls.Add(this.txtboxWindspd);
            this.groupBox4.Controls.Add(this.txtboxHumid);
            this.groupBox4.Controls.Add(this.txtboxPrecip);
            this.groupBox4.Controls.Add(this.txtboxMaxtemp);
            this.groupBox4.Controls.Add(this.txtboxMintemp);
            this.groupBox4.Controls.Add(this.txtboxCity);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Location = new System.Drawing.Point(39, 80);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(440, 423);
            this.groupBox4.TabIndex = 25;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Capture";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(35, 386);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(296, 13);
            this.label16.TabIndex = 42;
            this.label16.Text = "NB: To edit please select the row you want to edit.";
            // 
            // datetime
            // 
            this.datetime.CustomFormat = "dd-mm-yyyy";
            this.datetime.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datetime.Location = new System.Drawing.Point(206, 52);
            this.datetime.Name = "datetime";
            this.datetime.Size = new System.Drawing.Size(181, 20);
            this.datetime.TabIndex = 41;
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.DarkViolet;
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(279, 323);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(108, 47);
            this.btnClear.TabIndex = 40;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnEdit
            // 
            this.btnEdit.BackColor = System.Drawing.Color.DarkTurquoise;
            this.btnEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.Location = new System.Drawing.Point(158, 323);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(115, 47);
            this.btnEdit.TabIndex = 39;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = false;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnCapture
            // 
            this.btnCapture.BackColor = System.Drawing.Color.Gold;
            this.btnCapture.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCapture.Location = new System.Drawing.Point(38, 323);
            this.btnCapture.Name = "btnCapture";
            this.btnCapture.Size = new System.Drawing.Size(114, 47);
            this.btnCapture.TabIndex = 37;
            this.btnCapture.Text = "Capture";
            this.btnCapture.UseVisualStyleBackColor = false;
            this.btnCapture.Click += new System.EventHandler(this.btnCapture_Click);
            // 
            // txtboxWindspd
            // 
            this.txtboxWindspd.Location = new System.Drawing.Point(206, 257);
            this.txtboxWindspd.Name = "txtboxWindspd";
            this.txtboxWindspd.Size = new System.Drawing.Size(181, 20);
            this.txtboxWindspd.TabIndex = 36;
            // 
            // txtboxHumid
            // 
            this.txtboxHumid.Location = new System.Drawing.Point(206, 215);
            this.txtboxHumid.Name = "txtboxHumid";
            this.txtboxHumid.Size = new System.Drawing.Size(181, 20);
            this.txtboxHumid.TabIndex = 35;
            // 
            // txtboxPrecip
            // 
            this.txtboxPrecip.Location = new System.Drawing.Point(206, 174);
            this.txtboxPrecip.Name = "txtboxPrecip";
            this.txtboxPrecip.Size = new System.Drawing.Size(181, 20);
            this.txtboxPrecip.TabIndex = 34;
            // 
            // txtboxMaxtemp
            // 
            this.txtboxMaxtemp.Location = new System.Drawing.Point(206, 135);
            this.txtboxMaxtemp.Name = "txtboxMaxtemp";
            this.txtboxMaxtemp.Size = new System.Drawing.Size(181, 20);
            this.txtboxMaxtemp.TabIndex = 33;
            // 
            // txtboxMintemp
            // 
            this.txtboxMintemp.Location = new System.Drawing.Point(206, 91);
            this.txtboxMintemp.Name = "txtboxMintemp";
            this.txtboxMintemp.Size = new System.Drawing.Size(181, 20);
            this.txtboxMintemp.TabIndex = 32;
            // 
            // txtboxCity
            // 
            this.txtboxCity.Location = new System.Drawing.Point(206, 14);
            this.txtboxCity.Name = "txtboxCity";
            this.txtboxCity.Size = new System.Drawing.Size(181, 20);
            this.txtboxCity.TabIndex = 30;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(35, 260);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 16);
            this.label8.TabIndex = 29;
            this.label8.Text = "Wind speed";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(35, 218);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 16);
            this.label7.TabIndex = 28;
            this.label7.Text = "Humidity";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(35, 177);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 16);
            this.label6.TabIndex = 27;
            this.label6.Text = "Precipitation";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(35, 138);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(159, 16);
            this.label5.TabIndex = 26;
            this.label5.Text = "Maximum temperature";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(35, 94);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(159, 16);
            this.label4.TabIndex = 25;
            this.label4.Text = "Minimum temperature ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(35, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 16);
            this.label3.TabIndex = 24;
            this.label3.Text = "Date ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(35, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 16);
            this.label2.TabIndex = 23;
            this.label2.Text = "Specify city ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGreen;
            this.ClientSize = new System.Drawing.Size(1276, 837);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form1";
            this.Text = "Weather forecasting system";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridCity)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView gridCity;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker datetimeFrom;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker datetimeTo;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DateTimePicker datetimeTo2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker datetimeFrom2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnViewCity;
        private System.Windows.Forms.Button btnViewCities;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Button btnCapture;
        private System.Windows.Forms.TextBox txtboxWindspd;
        private System.Windows.Forms.TextBox txtboxHumid;
        private System.Windows.Forms.TextBox txtboxPrecip;
        private System.Windows.Forms.TextBox txtboxMaxtemp;
        private System.Windows.Forms.TextBox txtboxMintemp;
        private System.Windows.Forms.TextBox txtboxCity;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker datetime;
        private System.Windows.Forms.ComboBox City_select;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
    }
}

