﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task_1
{
    //class for all the functions in the Application form
    class Function_Class
    {

        //Declaration of variables
        DataTable dt = new DataTable(" weatherforecast");
        
        //method to initialize the datatable
        public void dt_Load()
        {
            dt.Columns.Add("City",typeof(string));
            dt.Columns.Add("Date");
            dt.Columns.Add("Minimum temperature",typeof(int));
            dt.Columns.Add("Maximum temperature",typeof(int));
            dt.Columns.Add("Precipitation", typeof(int));
            dt.Columns.Add("Humidity", typeof(int));
            dt.Columns.Add("Wind speed", typeof(int));



        }


        //Method To capture all the data and store to an array
        public void captureMethod(ComboBox cmbo_Search,TextBox txt_city, DateTimePicker datetime_val, TextBox txt_Min,TextBox txt_Max,TextBox Precip_val,TextBox Humid_val,TextBox Wind_spd)
        {
            try
            {
                if (txt_city.Text != null && txt_city.Text != "" && txt_Min.Text != "" && txt_Max.Text != "" && Precip_val.Text !="" &&Humid_val.Text!="" &&Wind_spd.Text!="")
                {

                    dt.Rows.Add(new[] { Convert.ToString(txt_city.Text), Convert.ToString(datetime_val.Text),Convert.ToString(txt_Min.Text),Convert.ToString(txt_Max.Text),
                                      Convert.ToString(Precip_val.Text),Convert.ToString(Humid_val.Text),Convert.ToString(Wind_spd.Text) });
                    MessageBox.Show("City forecast captured");
                }
                else
                {
                    MessageBox.Show("invalid forecast data! enter all details correctly.");
                }

                if (!cmbo_Search.Items.Contains(txt_city.Text))
                {
                    cmbo_Search.Items.Add(txt_city.Text);
                }
                   
                

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }           
        }


        //Method to display view data
        public void ViewMethod(DataGridView disp_data)
        {
            try
            {
             disp_data.DataSource = dt;
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //Method to Edit the selected specified city
        public void editMethod(TextBox City_val,DateTimePicker datetime, TextBox txt_Min, TextBox txt_Max, TextBox Precip_val, TextBox Humid_val, TextBox Wind_spd)
        {
          try
            {
                  foreach (DataRow row in dt.Rows)
                    {
                        if (row["City"].ToString() == City_val.Text)
                        {
                            row.SetField("City", City_val.Text);
                            row.SetField("Date", datetime.Text);
                            row.SetField("Minimum temperature", txt_Min.Text);
                            row.SetField("Maximum Temperature", txt_Max.Text);
                            row.SetField("Precipitation", Precip_val.Text);
                            row.SetField("Humidity", Humid_val.Text);
                            row.SetField("Wind speed", Wind_spd.Text);
                        }
                    }
                
               


            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //Method to clear all fields
        public void clearMethod(ComboBox City_val, TextBox txt_Min, TextBox txt_Max, TextBox Precip_val, TextBox Humid_val, TextBox Wind_spd,TextBox txt_search)
        {
            City_val.Text = "";
            txt_Min.Text = "";
            txt_Max.Text = "";
            Precip_val.Text = "";
            Humid_val.Text = "";
            Wind_spd.Text = "";
            txt_search.Text = "";
        }
        

        //method to search for each city and date range
        public void SearchMethod(ComboBox txtSearch ,DateTimePicker datetimeFrom,DateTimePicker datetimeTo,DataGridView disp_data)
        {
            try
            {
                if(txtSearch.Text !="")
                {
                    dt.DefaultView.RowFilter = null; 
                    disp_data.DataSource = dt;
                 //   dt.DefaultView.RowFilter = string.Format("[{0}] LIKE '%{1}%'", "City", txtSearch.Text);
                    dt.DefaultView.RowFilter = string.Format("[{0}] LIKE '%{2}%' AND [{1}] >= #{3}# AND [{1}] <=#{4}#","City","Date",txtSearch.Text,datetimeFrom.Text,datetimeTo.Text);
                    Min_Temp(disp_data);
                    Max_Temp(disp_data);

                }
                else
                {
                    MessageBox.Show("Search bar Empty.");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
          

        }
       
        
        //Search method for all the cities in a specified date range
        public void searchMethod2(DateTimePicker datetimeFrom, DateTimePicker datetimeTo, DataGridView disp_data)
        {
            try
            {
                dt.DefaultView.RowFilter = null; ;
                disp_data.DataSource = dt;
                dt.DefaultView.RowFilter = string.Format("[{0}] >=#{1}# AND [{0}] <=#{2}#","Date",datetimeFrom.Text,datetimeTo.Text);
                Max_Temp(disp_data);
                Min_Temp(disp_data);
                                
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        
        
        //method to find the largest temperature in the table
        public void Max_Temp( DataGridView disp_data)

        {


            int max = 0;

            //finding the maximum value
            for (int i = 0; i <disp_data.Rows.Count; i++)
            {
                if (disp_data.Rows[i].Cells[3].Value!=null)
                {
                        int temp = Int32.Parse(disp_data.Rows[i].Cells[3].Value.ToString());
             

                    if (max<temp)
                    {
                        max = temp;
                    }
                }
            
            }

          //setting the colour green for maximum temperature
            for (int i = 0; i < disp_data.Rows.Count; i++)
            {
                if (disp_data.Rows[i].Cells[3].Value != null)
                {
                    int temp = Int32.Parse(disp_data.Rows[i].Cells[3].Value.ToString());
                    if (temp==max)
                    {

                       disp_data.Rows[i].DefaultCellStyle.BackColor = Color.LightGreen;
                    }
                   
                }
            }
                                  
        
        }

        public void Min_Temp(DataGridView disp_data)
        {
            int Min_value = 101;
            //finding the mainimum value
            for (int i = 0; i < disp_data.Rows.Count; i++)
            {
                if (disp_data.Rows[i].Cells[2].Value != null)
                {
                    int temp = Int32.Parse(disp_data.Rows[i].Cells[2].Value.ToString());


                    if (Min_value > temp)
                    {
                        Min_value = temp;
                    }
                }

            }

            //setting the colour green for minimum temperature
            for (int i = 0; i < disp_data.Rows.Count; i++)
            {
                if (disp_data.Rows[i].Cells[2].Value != null)
                {
                    int temp = Int32.Parse(disp_data.Rows[i].Cells[2].Value.ToString());
                    if (temp == Min_value)
                    {

                        disp_data.Rows[i].DefaultCellStyle.BackColor = Color.Yellow;
                    }

                }
            }


        }
    }

    }

